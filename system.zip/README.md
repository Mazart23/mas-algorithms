# mas-algorithms

python3.13t -X gil=0 .\app.py